export interface Vulnerability {
  id: string;
  fileName: string;
  lineNumber: number;
  type: string;
  description: string;
  mitigation: string;
  unsafeCode: string;
  safeCode: string;
  explanation: string;
  category: string;
}

export interface ScanResult {
  id: string;
  timestamp: Date;
  fileName: string;
  vulnerabilities: Vulnerability[];
  summary: {
    total: number;
  };
  totalLines?: number;
  codeMetrics?: {
    cleanLines: number;
    vulnerableLines: number;
    codeHealthPercentage: number;
  };
}

export interface ScanHistory {
  id: string;
  timestamp: string;
  fileName: string;
  vulnerabilityCount: number;
  summary: string;
  result?: ScanResult;
}